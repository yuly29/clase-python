document.getElementById("miFormulario").addEventListener("submit", async function(e) {
    e.preventDefault();
    const nombre = document.getElementById("nombre").value;
    const email = document.getElementById("email").value;
    const edad = document.getElementById("edad").value;
    const numero = document.getElementById("numero").value;
    const res = await fetch("/procesar", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ nombre: nombre, email: email, edad: edad, numero: numero })
    });
    const data = await res.json();
    document.getElementById("respuesta").innerText = data.mensaje;
    document.getElementById("grafica").src = "static/grafica.png";
    document.getElementById("grafica_seaborn").src = "static/seaborn_grafica.png";

});

