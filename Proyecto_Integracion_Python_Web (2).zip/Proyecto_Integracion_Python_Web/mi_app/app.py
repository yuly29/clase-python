# importamos las librerias necesarias
from flask import Flask, render_template, request, jsonify # Para crear la web con flask
import pandas as pd  #Para manejar ddatos y archivos Excel
import os # Para comprobar si el archivo ya existente
import numpy as np # Para manejar datos numericos
import matplotlib
matplotlib.use('agg')
import matplotlib.pyplot as plt # para crear graficos
import datetime # Para manejar fechas y horas
import seaborn as sns

# Creamos la instqancia de la aplicacion flask
app = Flask(__name__)

# Ruta principal: carga la pagina HTML con el fomrulario
@app.route("/")
def index():
    return render_template("index.html", time=datetime.datetime.now().timestamp()) # Carga el archivo HTML desde / templates

# Definimo el nombre del archivo Excecl que usaremos ipara guardar los daatos
ARCHIVO = "usuarios.xlsx"


# Ruta para procesar datos enviados desdse el formulario
@app.route("/procesar", methods=["POST"])
def procesar():
    #obtener los datos JSon enviados de JAvascript
    data = request.get_json()
    nombre = data["nombre"] # Extraer el nombre
    email = data["email"] # Extraer el email
    edad = data["edad"] # Extraer la edad
    numero = data ["numero"] 
    numero = int(numero) if numero else 0
    edad = int(edad) if edad else 0
    
    
    # si el archivo Excel no existe, se crea con una columna "Nombre"
    if not os.path.exists(ARCHIVO):
        df = pd.DataFrame(columns=["Nombre", "Email", "edad", "numero"])
        edades = df["edad"].to_numpy()
        df.to_excel(ARCHIVO, index=False)
        promedio = np.mean(edades)
        
    # leer el archivo excel existente
    df = pd.read_excel (ARCHIVO)
    
    # Agregar el nuevo nombre como una nueva fila
    df.loc[len(df)] = [nombre, email, edad, numero]
    
    # Guardar el archivo actualizado (sobreescribirlo)
    df.to_excel(ARCHIVO, index=False)
    print(df)
    
   
    edades = df["edad"].to_numpy()
    promedio = np.mean(edades)
    valores = df["numero"].to_numpy()
    promedio_valores = np.mean(valores)    
   
    
    #crear grafico con matplotlib
    plt.figure()
    plt.plot(edades, marker="o")
    plt.title("Edades ingresadas")
    plt.xlabel("Ingreso N°")
    plt.ylabel("edad")
    plt.grid(True)
    plt.savefig("static/grafica.png")
    plt.close()
    
        
    #Seaborn
    plt.figure()
    sns.set_theme(style="darkgrid")
    df["numero"] = range(1, len(df)+ 1)
    sns.lineplot(data=df, x="numero", y=len(valores), marker="o")
    plt.title("Tendencia de valores (seaborn)")
    plt.savefig("static/seaborn_grafica.png")
    plt.close()
        
        
     # Preparar un mensaje de respuesta para enviar al frontend                         
    mensaje = f"Hola, {nombre}. ¡Tu información ha sido procesada con Python!, El promedio de las edades es : {promedio}"
    return jsonify({"mensaje": mensaje}) # Devolver respuesta en formato json

   
 # Ejecutar la aplicacion en modo de desarrollo si este archivo se ejecuta directamente   

if __name__ == "__main__":
    app.run(debug=True)
