document.getElementById("miFormulario").addEventListener("submit", async function(e) {
    e.preventDefault();
    const nombre = document.getElementById("nombre").value;
    const email = document.getElementById("email").value;
    const res = await fetch("/procesar", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ nombre: nombre, email: email })
    });
    const data = await res.json();
    document.getElementById("respuesta").innerText = data.mensaje;
});
