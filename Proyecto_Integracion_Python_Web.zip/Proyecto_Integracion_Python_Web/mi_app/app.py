from flask import Flask, render_template, request, jsonify
import pandas as pd 
import os
import openpyxl
app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

ARCHIVO = "usuarios.xlsx"




@app.route("/procesar", methods=["POST"])
def procesar():
    data = request.get_json()
    nombre = data["nombre"]
    email = data["email"]
    if not os.path.exists(ARCHIVO):
        df = pd.DataFrame(columns=["Nombre", "Email"])
        
        df.to_excel(ARCHIVO, index=False)
    
    df = pd.read_excel (ARCHIVO)
    df.loc[len(df)] = [nombre, email]
    
    df.to_excel(ARCHIVO, index=False)
    print(df)
                              
    mensaje = f"Hola, {nombre}. ¡Tu información ha sido procesada con Python!"
    return jsonify({"mensaje": mensaje})

if __name__ == "__main__":
    app.run(debug=True)
